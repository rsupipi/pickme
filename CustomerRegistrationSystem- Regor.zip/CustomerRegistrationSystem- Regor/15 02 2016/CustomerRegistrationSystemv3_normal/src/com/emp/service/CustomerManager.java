package com.emp.service;

import com.emp.model.Customer;
import java.util.List;

public interface CustomerManager {
	
	
	public List<Customer> getAllCustomers();
	public Customer getCustomers(int id);

	/**
	 * Add customer 
	 */
	public int createCustomers(Customer customer);
	public void deleteCustomers(int id);
	public void editCustomers(Customer customer);
}
